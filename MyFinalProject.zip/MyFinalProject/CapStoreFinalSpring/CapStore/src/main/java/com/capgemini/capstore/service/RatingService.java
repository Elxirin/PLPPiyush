package com.capgemini.capstore.service;




public interface RatingService {
	public String addRating( Integer productId, Integer rating);
	
	public double getAverageRating(Integer productId);
}
