package com.capgemini.capstore.exceptions;

public class AddressException extends Exception {
	
	public AddressException() {
		super();
	}
	
	public AddressException(String msg) {
		super(msg);
	}
}
