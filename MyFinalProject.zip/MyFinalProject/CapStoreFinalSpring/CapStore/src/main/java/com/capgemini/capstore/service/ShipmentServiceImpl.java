package com.capgemini.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Address;
import com.capgemini.capstore.beans.Description;
import com.capgemini.capstore.beans.Orders;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.Transaction;
import com.capgemini.capstore.dao.AddressRepository;
import com.capgemini.capstore.dao.DescRepository;
import com.capgemini.capstore.dao.OrderRepository;
import com.capgemini.capstore.dao.ProductRepository;
import com.capgemini.capstore.dao.TransRepository;
import com.capgemini.capstore.exceptions.AddressException;
import com.capgemini.capstore.exceptions.DescException;
import com.capgemini.capstore.exceptions.OrderException;
import com.capgemini.capstore.exceptions.ProductException;
import com.capgemini.capstore.exceptions.TransException;

@Service
public class ShipmentServiceImpl implements ShipmentService {

	@Autowired
	private AddressRepository addressRepository; 
	@Autowired
	private OrderRepository orderRepository;
	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private TransRepository transRepository;
	@Autowired
	private DescRepository descRepository;
	@Override
	public List<Address> getAddressDetails() throws AddressException {
		try {
			return addressRepository.findAll();
		} catch (Exception e) {
			throw new AddressException(e.getMessage());
		}
	}

	@Override
	public List<Orders> getOrderDetails() throws OrderException {
		try {
			return orderRepository.findAll();
		} catch (Exception e) {
			throw new OrderException(e.getMessage());
		}
		
	  }
	 
	 @Override
	 public List<Product> getProductDetails() throws ProductException {
		try {
			return productRepository.findAll();
		} catch (Exception e) {
			throw new ProductException("Product not exist");
		}
	 }
	

	 @Override
	 public List<Transaction> getTransDetails() throws TransException {
		 try {
			return transRepository.findAll();
		} catch (Exception e) {
			throw new TransException("Transaction not exist");
		}
	 }
	 
	
	@Override
	public List<Address> addAddressDetails(Address adr) throws AddressException {
		try {
			if(addressRepository.existsById(adr.getAddressId()));
		} catch (Exception e) {
			throw new AddressException(e.getMessage());
		}
		addressRepository.save(adr);
		
		return getAddressDetails();
	}

	
	 @Override
	 public List<Orders> addOrderDetails(Orders ord) throws OrderException {
		 System.out.println(ord.toString());
			if(orderRepository.existsById(ord.getOrderId()))
				throw new OrderException("order id does not exists");
			
		transRepository.save(ord.getTransaction());
		orderRepository.save(ord);
		return getOrderDetails();
	  }
	 
	 
	 @Override
	 public List<Product> addProductDetails(Product prod) throws ProductException {
		 if(productRepository.existsById(prod.getProductId()))
			 throw new ProductException("Product ID does not exists");
		 descRepository.saveAll(prod.getProductDesc());
		 productRepository.save(prod);
		
		 return getProductDetails();
	 }
	
	 @Override
	 public List<Transaction> addTransDetails(Transaction trans) throws TransException {
		 if(transRepository.existsById(trans.getTransactionId()))
			 throw new TransException("Transaction not exist");
		 transRepository.save(trans);
		 return getTransDetails();
	  }

	@Override
	public List<Description> getDescDetails() throws DescException {
		try {
			return descRepository.findAll();
		} catch (Exception e) {
			throw new DescException("Description not available");		}
	}

	@Override
	public List<Description> addDescDetails(Description desc) throws DescException {
		if(descRepository.existsById(desc.getDescId()))
			throw new DescException("Description ID does not exist");
		descRepository.save(desc);
		return getDescDetails();
	}	
		

	
}
