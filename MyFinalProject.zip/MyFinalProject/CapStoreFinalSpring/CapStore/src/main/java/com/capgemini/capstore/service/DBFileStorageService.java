package com.capgemini.capstore.service;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.capgemini.capstore.beans.Images;
import com.capgemini.capstore.dao.DBFileRepository;



@Service
public class DBFileStorageService {

	@Autowired
	private DBFileRepository dbFileRepository;

	public Images storeFile(MultipartFile file,int id) throws Exception {
		// Normalize file name
		String fileName = StringUtils.cleanPath(file.getOriginalFilename());

		try {
			// Check if the file's name contains invalid characters
			if (fileName.contains("..")) {
				throw new Exception("Sorry! Filename contains invalid path sequence " + fileName);
			}

			Images dbFile = new Images(id, fileName, file.getContentType(), file.getBytes());

			return dbFileRepository.save(dbFile);
		} catch (IOException ex) {
			throw new Exception("Could not store file " + fileName + ". Please try again!", ex);
		}
	}

	public Images getFile(String fileId) {
		return dbFileRepository.findById(fileId).get();
	}
	
	public List<ImageResponse> getAllProductImages(int productId){
		List<ImageResponse> urls = new ArrayList<ImageResponse>();
		List<String> url =dbFileRepository.getAllProductImages(productId); 
		for (String string : url) {
			urls.add(new ImageResponse("http://localhost:6500/downloadFile/"+string));
		}
		System.out.println(urls);
		return urls;
	}
}
