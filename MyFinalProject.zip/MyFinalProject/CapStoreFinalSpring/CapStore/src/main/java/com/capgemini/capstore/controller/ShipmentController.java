package com.capgemini.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Address;
import com.capgemini.capstore.beans.Description;
import com.capgemini.capstore.beans.Orders;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.Transaction;
import com.capgemini.capstore.exceptions.AddressException;
import com.capgemini.capstore.exceptions.DescException;
import com.capgemini.capstore.exceptions.OrderException;
import com.capgemini.capstore.exceptions.ProductException;
import com.capgemini.capstore.exceptions.TransException;
import com.capgemini.capstore.service.ShipmentService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ShipmentController {

	@Autowired
	private ShipmentService shipmentService;
	
	@RequestMapping("/addressDetails")
	public List<Address> getAddressDetails() throws AddressException{
		return shipmentService.getAddressDetails();
	}
	
	@PostMapping("/addressDetails")
	public List<Address> addAddressDetails(@RequestBody Address adr) throws AddressException{
		return shipmentService.addAddressDetails(adr);
	}
	
	@RequestMapping("/orderDetails")
	public List<Orders> getOrderDetails() throws OrderException{
		return shipmentService.getOrderDetails();
	}
	
	@PostMapping("/orderDetails")
	public List<Orders> addOrderDetails(@RequestBody Orders ord) throws OrderException{
		return shipmentService.addOrderDetails(ord);
	}
	
	@RequestMapping("/productDetails")
	public List<Product> getProductDetails() throws ProductException{
		return shipmentService.getProductDetails();
		
	}
	
	
	
	@PostMapping("/productDetails")
	public List<Product> addProductDetails(@RequestBody Product prod) throws ProductException{
		return shipmentService.addProductDetails(prod); 
	}
	
	@RequestMapping("/transDetails")
	public List<Transaction> getTransDetails() throws TransException{
		return shipmentService.getTransDetails();
	}
	
	@PostMapping("/transDetails")
	public List<Transaction> addTransDetails(@RequestBody Transaction trans) throws TransException{
		return shipmentService.addTransDetails(trans);
	}
	
	@RequestMapping("/descDetails")
	public List<Description> getDescDetails() throws DescException{
		return shipmentService.getDescDetails();
	}
	
	@PostMapping("/descDetails")
	public List<Description> addDescDetails(@RequestBody Description desc) throws DescException{
		return shipmentService.addDescDetails(desc);
	}
}
