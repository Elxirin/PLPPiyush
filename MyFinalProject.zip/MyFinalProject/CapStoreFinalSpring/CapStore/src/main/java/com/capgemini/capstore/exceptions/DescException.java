package com.capgemini.capstore.exceptions;

public class DescException extends Exception {

	public DescException() {
		super();
	}
	
	public DescException(String msg) {
		super(msg);
	}
}
