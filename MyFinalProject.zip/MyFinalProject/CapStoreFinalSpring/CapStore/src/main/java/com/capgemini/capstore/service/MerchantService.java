package com.capgemini.capstore.service;

import java.util.List;
import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.exceptions.MerchantException;


public interface MerchantService {
	public Merchant addMerchantRevenue(int id, double price) throws MerchantException;

	public List<Merchant> getAllTransactions() throws MerchantException;

	Merchant getMerchantById(int id) throws MerchantException;
	
	public List<Merchant> addMerchant(Merchant merchant) throws MerchantException;
	
}
