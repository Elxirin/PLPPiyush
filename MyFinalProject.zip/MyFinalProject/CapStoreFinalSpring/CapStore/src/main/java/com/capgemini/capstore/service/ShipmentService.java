package com.capgemini.capstore.service;

import java.util.List;

import com.capgemini.capstore.beans.Address;
import com.capgemini.capstore.beans.Description;
import com.capgemini.capstore.beans.Orders;
import com.capgemini.capstore.beans.Product;
import com.capgemini.capstore.beans.Transaction;
import com.capgemini.capstore.exceptions.AddressException;
import com.capgemini.capstore.exceptions.DescException;
import com.capgemini.capstore.exceptions.OrderException;
import com.capgemini.capstore.exceptions.ProductException;
import com.capgemini.capstore.exceptions.TransException;

;

public interface ShipmentService {
	List<Address> getAddressDetails() throws AddressException;
	List<Orders> getOrderDetails() throws OrderException;
	List<Product> getProductDetails() throws ProductException;
	List<Transaction> getTransDetails() throws TransException;
	List<Description> getDescDetails() throws DescException;
	
	List<Address> addAddressDetails(Address adr) throws AddressException;
	List<Orders> addOrderDetails(Orders ord) throws OrderException;
	List<Product> addProductDetails(Product prod) throws ProductException;
	List<Transaction> addTransDetails(Transaction trans) throws TransException;
	List<Description> addDescDetails(Description desc) throws DescException;
}
