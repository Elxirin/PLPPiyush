package com.capgemini.capstore.exceptions;

public class MerchantException extends Exception {
	public MerchantException() {
		super();
	}
	
	public MerchantException(String message) {
		super(message);
	}
}
