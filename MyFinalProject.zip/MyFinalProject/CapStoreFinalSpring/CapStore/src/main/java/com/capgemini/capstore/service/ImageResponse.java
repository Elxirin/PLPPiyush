package com.capgemini.capstore.service;

public class ImageResponse {
	private String url;

	public ImageResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ImageResponse(String url) {
		super();
		this.url = url;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Override
	public String toString() {
		return "ImageResponse [url=" + url + "]";
	}
	
}
