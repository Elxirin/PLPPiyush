package com.capgemini.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Merchant;
import com.capgemini.capstore.dao.MerchantRepository;
import com.capgemini.capstore.exceptions.MerchantException;

@Service
public class MerchantServiceImpl implements MerchantService {

	@Autowired
	private MerchantRepository merchantRepo;
	
	
	
	
	
	@Override
	public List<Merchant> getAllTransactions() throws MerchantException {
		try {
			return merchantRepo.findAll();
		} catch (Exception e) {
			throw new MerchantException(e.getMessage());
					}
	}

	
	@Override
    public Merchant getMerchantById(int id) throws MerchantException {
       
        if(!merchantRepo.existsById(id)) {
            throw new MerchantException("Merchant with id "+id+" does not exists");
        }else {
            return merchantRepo.findById(id).get();
        }
    }
	
	@Override
	public Merchant addMerchantRevenue(int id,double price) throws MerchantException {
		System.out.println(id+"    "+price);
		if (!merchantRepo.existsById(id)) {
			throw new MerchantException("Merchant with id " + id+ "does not exists");
		}
		Merchant m=getMerchantById(id);
		m.setRevenue(m.getRevenue()+price);
		merchantRepo.save(m);
		return getMerchantById(id);
	}


	@Override
	public List<Merchant> addMerchant(Merchant merchant) throws MerchantException {
		if(merchantRepo.existsById(merchant.getMerchantId())) {
			throw new MerchantException("Merchant with id " + merchant.getMerchantId() + "already exists");
		}
		merchantRepo.save(merchant);
		return getAllTransactions();
	}
	
}
