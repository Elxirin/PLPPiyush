package com.capgemini.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.ProductFeedback;
import com.capgemini.capstore.dao.FeedbackDao;

@Service	
public class RatingServiceImpl implements RatingService {

	@Autowired
	FeedbackDao feedbackDao;

	@Override
	public String addRating(Integer productId, Integer rating) {
		ProductFeedback feedback = new ProductFeedback();
		feedback.setProductId(productId);
		feedback.setRating(rating);
		feedbackDao.save(feedback);
		return feedback.getProductFeedbackId()+"";

	}

	@Override
	public double getAverageRating(Integer productId) {
		List<ProductFeedback> feedbacks = feedbackDao.findProductById(productId);
		int avg = 0, sum = 0;
		for (ProductFeedback productFeedback : feedbacks) {
			sum = sum + productFeedback.getRating();
		}

		return (double)sum / feedbacks.size();
	}

}
