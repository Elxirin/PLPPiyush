package com.capgemini.capstore.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class ProductFeedback {

	@Id
	@SequenceGenerator(name = "prodfeed_id", sequenceName = "prodfeed_id", initialValue = 80000, allocationSize = 1)
	@GeneratedValue(generator = "prodfeed_id")
	private int productFeedbackId;
	private int productId;
	private String feedback;
	private int rating;

	public ProductFeedback() {
		super();
	}

	public ProductFeedback(int productFeedbackId, int productId, String feedback, int rating) {
		super();
		this.productFeedbackId = productFeedbackId;
		this.productId = productId;
		this.feedback = feedback;
		this.rating = rating;
	}

	public int getProductFeedbackId() {
		return productFeedbackId;
	}

	public void setProductFeedbackId(int productFeedbackId) {
		this.productFeedbackId = productFeedbackId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	@Override
	public String toString() {
		return "ProductFeedback [productFeedbackId=" + productFeedbackId + ", productId=" + productId + ", feedback="
				+ feedback + ", rating=" + rating + "]";
	}

}
