export interface Image{
    imageId: String;
    productId: number;
    fileName: String;
}