import { Component, OnInit, Input } from '@angular/core';
import { Product } from './Product';
import { ProductService } from './product.service';
import { ImageService } from './image.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  bntStyle: string;
  products: Product[];
  images: any[];
  image1: string;
  image2: string;
  prod1: Product;
  prodIdToChild: number;
  @Input()
  prodIdFromPar: number;
  

  constructor(private prodService: ProductService, private imgService: ImageService,private activatedRoute: ActivatedRoute) {
    prodService.populateProduct().subscribe(data => this.products = data, error => console.log(error));
    
  }

  ngOnInit() {
    let code = this.activatedRoute.snapshot.paramMap.get('id');
    let id = +code;
    console.log("code:::::"+id);
    this.imgService.populateImages(id).subscribe(data => this.images = data, error => console.log(error));
    this.products = this.prodService.getProduct();
    this.images = this.imgService.getImages();
    setTimeout(() => {
      
      this.prod1 = this.products.find(x=>x.productId === id);
      this.prodIdToChild = this.prod1.productId;
      this.image1 = this.images[0].url;
      this.image2 = this.images[1].url;
      console.log(this.image1+" "+this.image2);
      console.log("Products:" + this.prod1.productDesc[0].value);
      console.log("sdfnsdadsfdsfsdfdsfsfsdf " + this.products.find(data=>data.productId===2001).productName);
    }, 150)
   
    
    console.log("to child "+this.prodIdToChild);
    console.log("from Parent ID"+this.prodIdFromPar);
    
  }


  addToWishlist() {
    console.log("here");
    this.bntStyle = 'btn-change';
    console.log("Products:" + this.prod1.productDesc.value);
    console.log("Image:" + this.images);

  }
}
