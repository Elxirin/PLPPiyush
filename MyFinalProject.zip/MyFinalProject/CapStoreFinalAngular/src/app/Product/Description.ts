export interface Description{
    descId: number;
    label: string;
    value: string;
}