import { Injectable } from '@angular/core';
import { Product } from './Product';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  products: Product[];
 

  constructor(private http: HttpClient) {
    //this.populateProduct().subscribe(data=>this.products=data, error=>console.log(error));
    
   }

   populateProduct():Observable<Product[]> {
      return this.http.get<Product[]>("http://localhost:6500/productDetails");
   }

   getProduct(): Product[] {
     return this.products;
   }

   addProduct(pr: Product){
     return this.http.post<Product>("http://localhost:6500/productDetails",pr);
    }
    
    
    
} 
