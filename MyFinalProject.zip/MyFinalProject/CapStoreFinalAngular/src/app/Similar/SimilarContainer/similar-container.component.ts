import { Component, OnInit, Input } from '@angular/core';
import { Product } from 'src/app/Product/Product';
import { SimilarService } from '../similar.service';

@Component({
  selector: 'app-similar-container',
  templateUrl: './similar-container.component.html',
  styleUrls: ['./similar-container.component.css']
})
export class SimilarContainerComponent implements OnInit {
  

  
  catId: number;

  @Input()
  prodId: number;

  

  similarProducts: Product[];
  prod1: Product;
  prodId1:number;
  prod2: Product;
  prod3: Product;
  prod4: Product;

  constructor(private similarService: SimilarService) { 
    this.similarService.populateSimilarProducts(this.prodId).subscribe(data => this.similarProducts = data, error => console.log(error));
    this.similarProducts = this.similarService.getSimilarProduct();
    setTimeout(() => {
      console.log(this.similarProducts.find(data=>data.productId===this.prodId).productName);
      this.catId = this.similarProducts.find(data=>data.productId===this.prodId).categoryId;
      this.similarProducts = this.similarProducts.filter(data=>data.categoryId===this.catId);
      this.similarProducts.forEach(element => {
        console.log(element.productName);
        
      });
      this.prod1 = this.similarProducts[0];
      this.prod2 = this.similarProducts[1];
      this.prod3 = this.similarProducts[2];
      this.prod4 = this.similarProducts[3];
      
      
    }, 150);
  }
  
  ngOnInit() {
    // this.similarService.populateSimilarProducts(this.prodId).subscribe(data=>this.similarProducts=data, error=>console.log(error) );
    
    
    

  }
}
