import { Component, OnInit, Input } from '@angular/core';
import { Product } from 'src/app/Product/Product';
import { ImageService } from 'src/app/Product/image.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-similar-product',
  templateUrl: './similar-product.component.html',
  styleUrls: ['./similar-product.component.css']
})
export class SimilarProductComponent implements OnInit {

  rateState:string ="checked";
  
  @Input()
  product: Product;

  @Input()
  prodId: number;

  images: any[];
  image1: string;
  image2: string;
  flag =false;


  constructor(private imgService: ImageService,private router: Router) { 
    
  }
  
  ngOnInit() {
    this.imgService.populateImages(this.product.productId).subscribe(data => this.images = data, error => console.log(error));
    
    this.images = this.imgService.getImages();
    setTimeout(() => {
      this.image1 = this.images[0].url;
      this.image2 = this.images[1].url;
      console.log(this.image1+" "+this.image2);
      
    }, 150)
  }
  
  onCardClick(){
    console.log(this.product.productName);
    this.router.navigate(['/product',{id: this.product.productId}]);
  }

  addToWishList() {
    this.flag=true;
  }

  getColor(){
    if(this.flag===false)
      return "gray";
    else
      return "red";
  }
  

}
