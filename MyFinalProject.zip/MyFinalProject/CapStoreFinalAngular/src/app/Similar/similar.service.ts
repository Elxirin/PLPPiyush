import { Injectable } from '@angular/core';
import { Product } from '../Product/Product';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SimilarService {
  similarProducts: Product[];
  
  prodId: number;
  
  constructor(private http:HttpClient) { 
    // this.populateSimilarProducts(this.prodId).subscribe(data=>this.similarProducts=data, error=>console.log(error));
  }

  populateSimilarProducts(prodId: number): Observable<Product[]>{
    console.log("here at service"+prodId);
    return this.http.get<Product[]>("http://localhost:6500/productDetails");
  }

  getSimilarProduct(): Product[]{
    return this.similarProducts;
  }

}
