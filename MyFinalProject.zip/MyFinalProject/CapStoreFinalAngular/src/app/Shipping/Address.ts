export interface Address {
    addressId: number;
    fullName: string;
    mobileNumber: string;
    pincode: string;
    streetAddress: string;
    city: string;
    state: string;
    type: string
}