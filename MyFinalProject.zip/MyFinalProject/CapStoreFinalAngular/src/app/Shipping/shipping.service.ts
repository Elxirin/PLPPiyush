import { Injectable } from '@angular/core';
import { Address } from './Address';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShippingService {
  address: Address[];
  constructor(private http: HttpClient) {

   }

   populateAddress(): Observable<Address[]> {
    return this.http.get<Address[]>("http://localhost:6500/addressDetails");
    }

    getAddress():Address[]{
      return this.address;
    }

    addAddress(address:Address){
      return this.http.post<Address[]>("http://localhost:6500/addressDetails", address).subscribe(data => this.address = data, error =>
      console.log(error));
      return this.getAddress();
    }


}
