import { Component, OnInit, ViewChild } from '@angular/core';
import { Address } from './Address';
import { Product } from '../Product/Product';
import { Description } from '../Product/Description';
import { NgForm } from '@angular/forms';
import { ShippingService } from './shipping.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-shipping',
  templateUrl: './shipping.component.html',
  styleUrls: ['./shipping.component.css']
})
export class ShippingComponent implements OnInit {
  address: Address[];
  
  
  @ViewChild('userForm',{static:false})
 public createProductForm:NgForm

  constructor(private shippingService: ShippingService, private router: Router) {
    this.shippingService.populateAddress().subscribe(data => { this.address = data; console.log(data); }, error => console.error());
  }

  ngOnInit() {

  }
  onSubmit(address:Address){
    this.shippingService.addAddress(address);
    alert("Shipping details added");
  }
}
