import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RatingService {
  avgRating: number=0;
  constructor(private http: HttpClient) { }
  addRating(rating, productId) {
    return this.http.post<any>("http://localhost:6500/rating/" + productId + "/" + rating, null).subscribe(data=>console.log(data))
  }

  populateAvgRating(id: number){
    return this.http.get<any>("http://localhost:6500/rating/average/"+id);
  }

  getAvgRating(){
    return this.avgRating;
  }


}
