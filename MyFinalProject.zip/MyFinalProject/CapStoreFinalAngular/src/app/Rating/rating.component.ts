import { Component, OnInit, Input } from '@angular/core';
import { RatingService } from './rating.service';

@Component({
  selector: 'app-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.css']
})
export class RatingComponent implements OnInit {

  @Input()
  prodId:number;

  ngOnInit(){

    
    this.ratingService.populateAvgRating(this.prodId).subscribe(data=>this.avgRating=data,error=>console.log(error));
    console.log(this.avgRating);
    console.log(this.prodId);
    

  }
  constructor(private ratingService:RatingService){
    
  }
  rating:number =0;
  avgRating:number = 0;
  addRating(){
    console.log(this.rating)
    if(this.rating === 0)
      alert("Please give rating");
      else
         this.ratingService.addRating(this.rating,this.prodId);

  }

}
