import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addressess',
  templateUrl: './addressess.component.html',
  styleUrls: ['./addressess.component.css']
})
export class AddressessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
