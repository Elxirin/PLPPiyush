import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HomeComponent } from './Home/home.component';

import {MatToolbarModule} from '@angular/material/toolbar';
import { MatMenuModule, MatButtonModule, MatIconModule, MatCardModule, MatBadgeModule,MatExpansionModule,MatRadioModule } from '@angular/material';
import { NavComponent } from './Home/Nav/nav.component';
import { ShopFilterComponent } from './Home/ShopFilter/shop-filter.component';

import { PaymentModeComponent } from './Payement/payment-mode.component';
import { WishlistComponent } from './WishList/wishlist.component';
import { ProductComponent } from './Product/product.component';
import { HttpClientModule } from '../../node_modules/@angular/common/http';
import { CartComponent } from './Cart/cart.component';
import { UserDashboardComponent } from './UserDashboard/user-dashboard.component';
import { EditProfileComponent } from './EditProfile/edit-profile.component';
import { OrdersComponent } from './Orders/orders.component';
import { AddressessComponent } from './Addressess/addressess.component';
import { RatingComponent } from './Rating/rating.component';
import { ShippingComponent } from './Shipping/shipping.component';
import { SimilarContainerComponent } from './Similar/SimilarContainer/similar-container.component';
import { SimilarProductComponent } from './Similar/SimilarProduct/similar-product.component';






@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavComponent,
    ShopFilterComponent,
    PaymentModeComponent,
    WishlistComponent,
    ProductComponent,
    CartComponent,
    UserDashboardComponent,
    EditProfileComponent,
    OrdersComponent,
    AddressessComponent,
    RatingComponent,
    ShippingComponent,
    SimilarContainerComponent,
    SimilarProductComponent,
    
   
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatCardModule,
    MatBadgeModule,
    MatExpansionModule,
    MatRadioModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
