import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WishlistComponent } from './WishList/wishlist.component';
import { CartComponent } from './Cart/cart.component';
import { UserDashboardComponent } from './UserDashboard/user-dashboard.component';
import { EditProfileComponent } from './EditProfile/edit-profile.component';
import { OrdersComponent } from './Orders/orders.component';
import { AddressessComponent } from './Addressess/addressess.component';
import { HomeComponent } from './Home/home.component';
import { ProductComponent } from './Product/product.component';


const routes: Routes = [
  
  {path:"home", component:HomeComponent},
  {path:"wishlist", component: WishlistComponent},
  {path:"cart",component: CartComponent},
  {path:"userDashboard", component: UserDashboardComponent},
  {path:"editProfile", component: EditProfileComponent},
  {path:"orders", component: OrdersComponent},
  {path:"addresses", component: AddressessComponent},
  {path:"product", component: ProductComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
