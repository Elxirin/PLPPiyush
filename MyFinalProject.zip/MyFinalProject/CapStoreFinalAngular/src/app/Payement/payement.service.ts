import { Injectable } from '@angular/core';
import { Merchant } from './Merchant';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PayementService {
  merchants: Merchant[];
  merchant: Merchant;
  id: number=30000;
  price: number = 1000;
  constructor(private http: HttpClient) {
      this.populateMerchant(this.id).subscribe(data=>this.merchant=data, error=>console.log(error));
   }


   populateMerchant(id: number){
     return this.http.get<Merchant>("http://localhost:6500/merchant/"+id);
   }

   getMerchant(){
     return this.getMerchant();
   }

   addRevenue(id: number,price: number){
      console.log("here at service");
      return this.http.get<Merchant>("http://localhost:6500/merchant/"+id+"/"+price).subscribe(data=>this.merchant=data, error=> console.log(error) );
    
   }


}
