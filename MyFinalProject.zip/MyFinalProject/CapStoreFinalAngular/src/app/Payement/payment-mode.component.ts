import { Component, OnInit } from '@angular/core';
import { PayementService } from './payement.service';
import { Merchant } from './Merchant';

@Component({
  selector: 'app-payment-mode',
  templateUrl: './payment-mode.component.html',
  styleUrls: ['./payment-mode.component.css']
})
export class PaymentModeComponent implements OnInit {

  merchant: Merchant;
  id:number = 30000;
  price: number = 1000;
  constructor(private payementService: PayementService) {
      this.payementService.populateMerchant(this.id).subscribe(data=>this.merchant=data, error=>console.log(error));
   }

  ngOnInit() {
    this.merchant = this.payementService.getMerchant();
  }

  onSubmit() {

    console.log("hereat Merchant  "+this.merchant.firstName);
    this.payementService.addRevenue(this.id,this.price);
    console.log("add revenue called");
    
    
    
  }

}
